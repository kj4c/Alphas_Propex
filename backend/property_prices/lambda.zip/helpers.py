def avg_surburb_income(data):
    """
    implementation of commercial_recs
    """
    return "yo"
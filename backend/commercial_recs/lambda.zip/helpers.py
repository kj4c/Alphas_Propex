def find_commerical_recs(data):
    """
    implementation of commercial_recs
    """
    return "yoooo"